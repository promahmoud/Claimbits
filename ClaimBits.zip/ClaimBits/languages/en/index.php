<?php
	/* English language pack */
	$c_lang['active'] = '1'; 				// Set 0 to disable this language

	$c_lang['lang'] 	= 'English';		// Language name
	$c_lang['code'] 	= 'en';				// This must be the same with folder name
	$c_lang['vers'] 	= '2.0.0';			// Version
	$c_lang['charset'] 	= 'UTF-8';		// Charset

	// Do no edit these lines
	$c_lang[$c_lang['code'].'_charset'] = $c_lang['charset'];
?>