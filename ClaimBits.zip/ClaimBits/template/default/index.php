<?php
	if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
	
	/* Theme Config */
	$theme['code']		= 'default';
	$theme['name']  		= 'Default';
	$theme['version']  	= '1.0';

	/* Author */
	$theme['author']		= 'MN Shop';
	$theme['website']	= 'www.MN-Shop.com';
?>